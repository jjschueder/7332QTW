getwd()
setwd("/Users/bblanchard006/Desktop/SMU/QTW/Case Studies/Unit 6 Case Study")

load("data.Rda") 
